/**
 * @file student.c
 * @author Sharmin Ahmed
 * @brief This file contains the functions that oeprate student information related tasks/operations.
 * @version 0.1
 * @date 2022-04-12
 * @copyright Copyright (c) 2022
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * Adds a student's grade to their record. 
 * 
 * @param student A certain student of Student type.
 * @param grade A student's grade of double type.
 * @return nothing
 */
void add_grade(Student* student, double grade)
{
  // Increases the number of grades a student has by one.
  student->num_grades++;
  // Assigns the appropriate memory to store a student's grade.
  // If this is the student's first grade, a block of memory on the heap is allocated to store a double type.
  // If this is not the student's first grade, a block of memory is re-allocated to a double type.
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }

  // Adds the student's grade into their record.
  student->grades[student->num_grades - 1] = grade;
}

/**
 * Calculates a student's average grade.
 * 
 * @param student A certain student of Student type.
 * @return The student's average grade.
 */
double average(Student* student)
{
  // If the student does not have any grades, return 0.
  if (student->num_grades == 0) return 0;

  // Creates a variable to keep track of a student's total grade (add all grades together).
  // This is made to carry out an average calculation.
  double total = 0;
  // Loops through a student's record of grades and adds them to the total variable.
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  // Returns a student's average.
  return total / ((double) student->num_grades);
}

/**
 * Prints out a student's information.
 * 
 * @param student A certain student of Student type.
 * @return nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // Loops through to get every grade of a student and prints it out.
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * This function randomly generates a student from a set of information.
 * 
 * @param grades A certain number of grades the new student will have of int type.
 * @return The newly generated student.
 */
Student* generate_random_student(int grades)
{
  // A set of first and last names to be used to generate a student's name.
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  // Allocates a block of memory from the heap to store a new student's information.
  Student *new_student = calloc(1, sizeof(Student));

  // Randomly generates a first and last name, and then assigns that name to the new student's record of information.
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // Assigns the student a random student ID by randonly generating 10 numbers.
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // Assigns the student a randomly generated grade.
  // The number of grades the student will have is given in the parameter.
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  // Returns the newly generated student's information.
  return new_student;
}