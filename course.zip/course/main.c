/**
 * @file main.c
 * @author Sharmin Ahmed
 * @brief This file contains a function that creates a course and a number of students to be enrolled into the created course.
 * @version 0.1
 * @date 2022-04-12
 * @copyright Copyright (c) 2022
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * This function creates a course and a number of students that are then enrolled into the created course.
 * 
 * @return nothing
 */
int main()
{
  // Randomizes seed to change the random algorithm.
  srand((unsigned) time(NULL));

  // Allocates a block of memory from the heap to store a Couese type variable.
  Course *MATH101 = calloc(1, sizeof(Course));

  // Assigns the created Course type variable a name and course code.
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // Generates 20 random students to enroll into the course.
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  // Prints out the course information.
  print_course(MATH101);

  // Finds the top graded student in a particular math course and prints out their information.
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // Finds the total number of passing students and said number of student's information.
  // Prints out the number of passing students.
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);

  // Prints the student information of each passing student.
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}