/**
 * @file course.c
 * @author Sharmin Ahmed
 * @brief This file contains the functions that operate course information related tasks/operations.
 * @version 0.1
 * @date 2022-04-12
 * @copyright Copyright (c) 2022
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * Enrolls a particular student into a particular course.
 * 
 * @param course A certain course of Course type.
 * @param student A certain student of Student type.
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  // Increase the total number of student counter by one.
  course->total_students++;
  // Assigns the appropriate memory to store a students information.
  // If this is the first enrolled student of a course, a block of memory on the heap is allocated to store a Student type.
  // If this is not the first enrolled student of a course, a block of memory is re-allocated to store a Student type.
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }

  // Adds the student information into the course information.
  course->students[course->total_students - 1] = *student;
}

/**
 * Prints out the course information of a Course type.
 * This includes the name, code, total number of students, and student information of a course.
 * 
 * @param course A certain course of Course type.
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // Loops through each student of a course and prints out their information by calling the print_student function.
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * Finds the top graded student of a certain course.
 * 
 * @param course A certain course of Course type.
 * @return The top graded student of a course (Student type).
 */
Student* top_student(Course* course)
{ 
  // If there are no students in a course, return nothing. 
  if (course->total_students == 0) return NULL;
 
  // Sets a variable to keep track of a student's average (student_average)
  // and a variable to keep track of the highest student average.
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  // Loops through each student of a course and finds the student with the highest average
  // among all the students of that course.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      // Sets the student average larger than the max average to max average (making that average the max average).
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  // After the top student is found, they are returned.
  return student;
}

/**
 * Finds the number of passing students and all of those students information.
 * 
 * @param course A certain course of Course type.
 * @param total_passing Total number of passing students.
 * @return Returns an array of passing the passing students information.
 */
Student *passing(Course* course, int *total_passing)
{
  // Sets a variable to count the number of passing students (count)
  // and a Student variable to keep track of the passing student's information.
  int count = 0;
  Student *passing = NULL;
  
  // Loops through all students through a course and checks if their average is above 50% (passing).
  // Each time a student is found to be passing, the count variable increases by one.
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // Allocates the passing variable a block of memory from the heap that can store "count" times of student information.
  passing = calloc(count, sizeof(Student));

  // Assigns each found passing student's information into the passing variable.
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  // Assigns the total passing variable the counted number of passing students.
  *total_passing = count;

  // Returns all the passing students information.
  return passing;
}