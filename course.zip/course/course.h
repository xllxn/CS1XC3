/**
 * @file course.h
 * @author Sharmin Ahmed
 * @brief Header file that contains the function and struct/typedef declarations of course.c
 * @version 0.1
 * @date 2022-04-12
 * @copyright Copyright (c) 2022
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * Course type stores the course information with fields name, code, students, total_students.
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;


/**
 * Instantiates the enroll_student function that is responsible for enrolling a student into a course.
 */
void enroll_student(Course *course, Student *student);

/**
 * Instantiates the print_course function that is responsible for printing the course info of a course.
 */
void print_course(Course *course);

/**
 * Instatiates the top_student function that is responsible for finding the top graded student of a course.
 */
Student *top_student(Course* course);

/**
 * Instatiates the passing function that is responsible for finding the number of passing students and those students information.
 */
Student *passing(Course* course, int *total_passing);


