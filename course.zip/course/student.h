 
/**
 * @file student.h
 * @author Sharmin Ahmed
 * @brief Header file that contains the function and struct/typedef declarations of student.c
 * @version 0.1
 * @date 2022-04-12
 * @copyright Copyright (c) 2022
 */

/**
 * Student type stores the student information with fields first_name, last_name, id, grades, num_grades.
 */ 
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * Instantiates the add_grade function that is responsible for adding a grade to a student's record.
 */
void add_grade(Student *student, double grade);

/**
 * Instantiates the average function that is responsible for calculating a student's average.
 */
double average(Student *student);

/**
 * Instantiates the print_student function that is responsible for printing a student's information.
 */
void print_student(Student *student);

/**
 * Instantiates the generate_random_student function that is responsible for randomly generating a new student.
 */
Student* generate_random_student(int grades); 
